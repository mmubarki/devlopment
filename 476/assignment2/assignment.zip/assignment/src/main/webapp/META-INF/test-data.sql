
insert into Mussa.User(name,email,password) values (
        'Mussa Mubarki','mmubarki@gmail.com','123456');
insert into Mussa.Event(title,description,location,eventTime,createdBy) 
        values ('Summit Event Productions',
        'We are a boutique lighting design production company based in the MD/DC/VA area',
        '2627 e la palma ave',
        '2017-01-21 13:00:00',1);